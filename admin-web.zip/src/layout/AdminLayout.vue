<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const activeMenu = computed(() => {
  if (route.path.startsWith('/hazard-map')) return '/hazard-map'
  if (route.path.startsWith('/hazards')) return '/hazards'
  if (route.path.startsWith('/work-orders')) return '/work-orders'
  if (route.path.startsWith('/knowledge')) return '/knowledge'
  if (route.path.startsWith('/ai-assistant')) return '/ai-assistant'
  return '/dashboard'
})
const pageTitle = computed(() => route.meta.title || '首页')
const today = new Date().toLocaleDateString('zh-CN', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
  weekday: 'long',
})
</script>

<template>
  <el-container class="admin-shell">
    <el-aside class="admin-aside" width="220px">
      <div class="brand">
        <div class="brand-mark">PL</div>
        <div>
          <div class="brand-title">AI巡检</div>
          <div class="brand-subtitle">Safety Console</div>
        </div>
      </div>

      <div class="menu-group">功能导航</div>

      <el-menu :default-active="activeMenu" router class="side-menu">
        <el-menu-item index="/dashboard">
          <el-icon>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12" />
              <path d="M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125h3.375v-4.125c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21h3.375c.621 0 1.125-.504 1.125-1.125V9.75" />
            </svg>
          </el-icon>
          <span>首页</span>
        </el-menu-item>

        <el-menu-item index="/hazard-map">
          <el-icon>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
              <path d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </el-icon>
          <span>航道一张图</span>
        </el-menu-item>

        <el-menu-item index="/hazards">
          <el-icon>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126z" />
              <path d="M12 15.75h.008v.008H12v-.008z" />
            </svg>
          </el-icon>
          <span>隐患管理</span>
        </el-menu-item>

        <el-menu-item index="/work-orders">
          <el-icon>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M15.666 3.888A2.25 2.25 0 0013.5 2.25h-3c-1.03 0-1.9.693-2.166 1.638m7.332 0c.055.194.084.4.084.612v0a.75.75 0 01-.75.75H9a.75.75 0 01-.75-.75v0c0-.212.03-.418.084-.612m7.332 0c.646.049 1.288.11 1.927.184 1.1.128 1.907 1.077 1.907 2.185V19.5a2.25 2.25 0 01-2.25 2.25H6.75A2.25 2.25 0 014.5 19.5V6.767c0-1.108.806-2.057 1.907-2.185a48.208 48.208 0 011.927-.184" />
              <path d="M9 12h6M9 15.75h4.5" />
            </svg>
          </el-icon>
          <span>工单管理</span>
        </el-menu-item>

        <el-menu-item index="/knowledge">
          <el-icon>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
            </svg>
          </el-icon>
          <span>知识库管理</span>
        </el-menu-item>

        <el-menu-item index="/ai-assistant">
          <el-icon>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.076-4.076a1.526 1.526 0 011.037-.443 48.282 48.282 0 005.68-.494c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" />
            </svg>
          </el-icon>
          <span>AI航运助手</span>
        </el-menu-item>
      </el-menu>

      <div class="aside-footer">
        <span class="aside-avatar">管</span>
        <div>
          <div class="aside-user-name">管理员</div>
          <div class="aside-user-role">已登录</div>
        </div>
      </div>
    </el-aside>

    <el-container>
      <el-header class="admin-header">
        <div>
          <h1>平陆运河AI水上安全巡检平台</h1>
          <p>{{ pageTitle }}</p>
        </div>
        <div class="header-meta">
          <span class="header-date">{{ today }}</span>
        </div>
      </el-header>

      <el-main class="admin-main">
        <router-view v-slot="{ Component }">
          <transition name="page-fade" mode="out-in">
            <component :is="Component" />
          </transition>
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
